﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private double _pierwszaLiczba = 0;
        private double _drugaLiczba = 0;
        private string _dzialanie = "";
        private bool _czyWybranoDzialanie = false;

        public MainWindow()
        {
            InitializeComponent();
            PrzypiszZdarzenia();
        }

        private void PrzypiszZdarzenia()
        {
            but0.Click += PrzyciskLiczby_Click;
            but1.Click += PrzyciskLiczby_Click;
            but2.Click += PrzyciskLiczby_Click;
            but3.Click += PrzyciskLiczby_Click;
            but4.Click += PrzyciskLiczby_Click;
            but5.Click += PrzyciskLiczby_Click;
            but6.Click += PrzyciskLiczby_Click;
            but7.Click += PrzyciskLiczby_Click;
            but8.Click += PrzyciskLiczby_Click;
            but9.Click += PrzyciskLiczby_Click;
            kropka.Click += PrzyciskKropka_Click;
            dodawanie.Click += PrzyciskDzialania_Click;
            odejmowanie.Click += PrzyciskDzialania_Click;
            mnozenie.Click += PrzyciskDzialania_Click;
            dzielenie.Click += PrzyciskDzialania_Click;
            czysc.Click += PrzyciskCzysc_Click;
        }

        private void PrzyciskLiczby_Click(object sender, RoutedEventArgs e)
        {
            var przycisk = sender as Button;
            if (textBox.Text == "0" || _czyWybranoDzialanie)
            {
                textBox.Text = przycisk.Content.ToString();
                _czyWybranoDzialanie = false;
            }
            else
            {
                textBox.Text += przycisk.Content.ToString();
            }
        }

        private void PrzyciskKropka_Click(object sender, RoutedEventArgs e)
        {
            if (!textBox.Text.Contains(","))
            {
                textBox.Text += ",";
            }
        }

        private void PrzyciskDzialania_Click(object sender, RoutedEventArgs e)
        {
            var przycisk = sender as Button;
            _pierwszaLiczba = double.Parse(textBox.Text);
            _dzialanie = przycisk.Content.ToString();
            _czyWybranoDzialanie = true;
        }

        private void rownasie_Click(object sender, RoutedEventArgs e)
        {
            if (!double.TryParse(textBox.Text, out _drugaLiczba))
            {
                textBox.Text = "Błąd";
                return;
            }

            double wynik = 0;
            switch (_dzialanie)
            {
                case "+":
                    wynik = _pierwszaLiczba + _drugaLiczba;
                    break;
                case "-":
                    wynik = _pierwszaLiczba - _drugaLiczba;
                    break;
                case "*":
                    wynik = _pierwszaLiczba * _drugaLiczba;
                    break;
                case "/":
                    if (_drugaLiczba == 0)
                    {
                        textBox.Text = "Błąd";
                        return;
                    }
                    wynik = _pierwszaLiczba / _drugaLiczba;
                    break;
                default:
                    textBox.Text = "Błąd";
                    return;
            }
            textBox.Text = wynik.ToString();
            _czyWybranoDzialanie = true;
        }

        private void PrzyciskCzysc_Click(object sender, RoutedEventArgs e)
        {
            textBox.Text = "0";
            _pierwszaLiczba = 0;
            _drugaLiczba = 0;
            _dzialanie = "";
            _czyWybranoDzialanie = false;
        }
    }
}   