﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace prosty_kalkulator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOblicz_Click(object sender, RoutedEventArgs e)
        {
            double a, b, wynik = 0;
            if (double.TryParse(txtA.Text, out a) && double.TryParse(txtB.Text, out b))
            {
                if (rbDodaj.IsChecked == true)
                    wynik = a + b;
                else if (rbOdejmij.IsChecked == true)
                    wynik = a - b;
                else if (rbPomnoz.IsChecked == true)
                    wynik = a * b;
                else if (rbPodziel.IsChecked == true)
                    wynik = b != 0 ? a / b : double.NaN;

                txtWynikBox.Text = wynik.ToString();
            }
            else
            {
                txtWynikBox.Text = "Błąd danych";
            }
        }
    }
}